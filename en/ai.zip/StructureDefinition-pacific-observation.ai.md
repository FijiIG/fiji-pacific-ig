# Pacific Observation - Fiji Pacific Core Implementation Guide v0.2.1

## Resource Profile: Pacific Observation 

 
Profile of Observation as defined for South Pacific. 

**Usages:**

* Derived from this Profile: [Blood Pressure Observation (Pacific region)](StructureDefinition-pacific-vital-blood-pressure.md), [BMI Vitals (Pacific region)](StructureDefinition-pacific-vital-bmi.md), [Body Temperature Vitals (Pacific region)](StructureDefinition-pacific-vital-body-temperature.md), [Heart Rate Vitals (Pacific region)](StructureDefinition-pacific-vital-heart-rate.md)... Show 4 more, [Height Vitals (Pacific region)](StructureDefinition-pacific-vital-height.md), [Oxygen Saturation Vitals (Pacific region)](StructureDefinition-pacific-vital-oxygen-saturation.md), [Respiratory Rate Vitals (Pacific region)](StructureDefinition-pacific-vital-respiratory-rate.md) and [Weight Vitals (Pacific region)](StructureDefinition-pacific-vital-weight.md)

You can also check for [usages in the FHIR IG Statistics](https://packages2.fhir.org/xig/resource/hl7.fhir.uv.pacific.core|current/StructureDefinition/StructureDefinition-pacific-observation.json)

### Formal Views of Profile Content

 [Description Differentials, Snapshots, and other representations](http://build.fhir.org/ig/FHIR/ig-guidance/readingIgs.html#structure-definitions). 

 

Other representations of profile: [CSV](../StructureDefinition-pacific-observation.csv), [Excel](../StructureDefinition-pacific-observation.xlsx), [Schematron](../StructureDefinition-pacific-observation.sch) 



## Resource Content

```json
{
  "resourceType" : "StructureDefinition",
  "id" : "pacific-observation",
  "url" : "https://fijiig.github.io/fiji-pacific-ig/StructureDefinition/pacific-observation",
  "version" : "0.2.1",
  "name" : "PacificObservation",
  "title" : "Pacific Observation",
  "status" : "draft",
  "date" : "2026-07-02T02:47:53+00:00",
  "publisher" : "HealthInfoServices",
  "contact" : [{
    "name" : "HealthInfoServices",
    "telecom" : [{
      "system" : "url",
      "value" : "https://healthinfoservices.net"
    }]
  },
  {
    "name" : "Support",
    "telecom" : [{
      "system" : "url",
      "value" : "https://www.healthinfoservices.net"
    }]
  }],
  "description" : "Profile of Observation as defined for South Pacific.",
  "jurisdiction" : [{
    "coding" : [{
      "system" : "http://unstats.un.org/unsd/methods/m49/m49.htm",
      "code" : "001",
      "display" : "World"
    }]
  }],
  "copyright" : "Distributed under the Creative Commons CC0-1.0 License (https://creativecommons.org/publicdomain/zero/1.0/)",
  "fhirVersion" : "4.0.1",
  "mapping" : [{
    "identity" : "workflow",
    "uri" : "http://hl7.org/fhir/workflow",
    "name" : "Workflow Pattern"
  },
  {
    "identity" : "sct-concept",
    "uri" : "http://snomed.info/conceptdomain",
    "name" : "SNOMED CT Concept Domain Binding"
  },
  {
    "identity" : "v2",
    "uri" : "http://hl7.org/v2",
    "name" : "HL7 v2 Mapping"
  },
  {
    "identity" : "rim",
    "uri" : "http://hl7.org/v3",
    "name" : "RIM Mapping"
  },
  {
    "identity" : "w5",
    "uri" : "http://hl7.org/fhir/fivews",
    "name" : "FiveWs Pattern Mapping"
  },
  {
    "identity" : "sct-attr",
    "uri" : "http://snomed.org/attributebinding",
    "name" : "SNOMED CT Attribute Binding"
  }],
  "kind" : "resource",
  "abstract" : false,
  "type" : "Observation",
  "baseDefinition" : "http://hl7.org/fhir/StructureDefinition/Observation",
  "derivation" : "constraint",
  "differential" : {
    "element" : [{
      "id" : "Observation",
      "path" : "Observation"
    },
    {
      "id" : "Observation.category",
      "path" : "Observation.category",
      "binding" : {
        "strength" : "preferred",
        "valueSet" : "http://hl7.org/fhir/ValueSet/observation-category"
      }
    },
    {
      "id" : "Observation.code",
      "path" : "Observation.code",
      "binding" : {
        "strength" : "preferred",
        "valueSet" : "https://fijiig.github.io/fiji-pacific-ig/ValueSet/obs-vs"
      }
    },
    {
      "id" : "Observation.subject",
      "path" : "Observation.subject",
      "type" : [{
        "code" : "Reference",
        "targetProfile" : ["https://fijiig.github.io/fiji-pacific-ig/StructureDefinition/pacific-patient"]
      }]
    }]
  }
}

```
