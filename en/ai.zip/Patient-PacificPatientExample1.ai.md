# PacificPatientExample1 - Fiji Pacific Core Implementation Guide v0.2.1

## Example Patient: PacificPatientExample1

Profile: [Pacific Patient](StructureDefinition-pacific-patient.md)

Taviri Male, DoB: 1990-04-12 ( http://health.example.org/fhir/identifier#123456789)

-------

| | |
| :--- | :--- |
| Alt. Name: | Michael Taviri Kalo(Official) |
| [Pacific Clan Affiliation](StructureDefinition-pacific-clan-affiliation.md) | Nakamal Vaturanga |



## Resource Content

```json
{
  "resourceType" : "Patient",
  "id" : "PacificPatientExample1",
  "meta" : {
    "profile" : ["https://fijiig.github.io/fiji-pacific-ig/StructureDefinition/pacific-patient"]
  },
  "extension" : [{
    "url" : "https://fijiig.github.io/fiji-pacific-ig/StructureDefinition/pacific-clan-affiliation",
    "valueCodeableConcept" : {
      "text" : "Nakamal Vaturanga"
    }
  }],
  "identifier" : [{
    "system" : "http://health.example.org/fhir/identifier",
    "value" : "123456789"
  }],
  "name" : [{
    "use" : "official",
    "text" : "Michael Taviri Kalo",
    "family" : "Kalo",
    "given" : ["Michael", "Taviri"]
  },
  {
    "use" : "usual",
    "text" : "Taviri",
    "given" : ["Taviri"]
  }],
  "gender" : "male",
  "birthDate" : "1990-04-12"
}

```
